<?php 
include '../conexion/conexion.php';

$selMoti=$con->query("SELECT * FROM cie");//consulta

$data = [];//crear array

foreach ($selMoti as $key => $value) //recorremos todos los datos de la consulta y asociamos a value
	{
		$data[] = array(
			"codigo" => $value['codigo'].' - '.$value['descripcion'],
			"descripcion" => $value['descripcion'],
			"sexo" => $value['sexo']
		);
	}
	echo json_encode($data,JSON_UNESCAPED_UNICODE);//se crea el json y se envia para utilizar
?>